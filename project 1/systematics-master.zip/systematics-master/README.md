# systematics
I created a PSD to HTML Tutorial serials. This series is completed and the code is ready for anyone who want to learn PSD to HTML too. Here is the source code

❤️❤️ 
=====================================================
=> Download PSD file for practice. 
=> If Download link not working 
=> Please change "systematic.png" => "systematic.psd" 

🍕🍕🌮🌮 Tutorial Link
=====================================
https://www.youtube.com/watch?v=caU5LShRWmQ&list=PLSNRR4BKcowB_4GEaKQMytLgddc9-PZ0x&index=2

